package com.cleo.algorithms.trees;

public class Pair{

    TreeNode node; int data;

    public Pair(TreeNode node, int data) {
        this.node = node;
        this.data = data;

    }

}

