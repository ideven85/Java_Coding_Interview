package com.cleo.algorithms.hashing;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;

// TODO: 01/09/23 "Implement me" 
public class SubArraySum {
    //Return the number of sub arrays which sum to k
    public static int subarraySum(int[] arr, int k) {
        int count=0;
        int n = arr.length;
        Arrays.sort(arr);
        return count;

    }

    public static void main(String[] args) {

    }

}
