package com.cleo.algorithms.trees;

public class TreeNode{
    int val;
    TreeNode left,right;

    public TreeNode(int val) {
        this.val = val;
        this.left=null;
        this.right=null;
    }

    public TreeNode() {
    }
}