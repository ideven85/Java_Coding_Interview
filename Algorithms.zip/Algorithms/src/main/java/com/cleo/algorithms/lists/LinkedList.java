package com.cleo.algorithms.lists;

public class LinkedList {
    int value;
    LinkedList next = null;

    public LinkedList(int value) {
        this.value = value;
    }
}