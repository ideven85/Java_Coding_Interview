package com.cleo.algorithms.strings;

public class FirstNonRepeatingCharacter {
    public int firstNonRepeatingCharacter(String string) {
        // Write your code here.

        boolean found = false;
        for (int i = 0; i < string.length(); i++) {


        }
        return -1;
    }

    public static void main(String[] args) {
        String s = "abcdcaf";
        FirstNonRepeatingCharacter first = new FirstNonRepeatingCharacter();
        System.out.println(first.firstNonRepeatingCharacter(s));
    }
}
