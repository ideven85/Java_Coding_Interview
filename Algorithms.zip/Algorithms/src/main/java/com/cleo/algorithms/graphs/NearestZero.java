package com.cleo.algorithms.graphs;

import java.util.LinkedList;
import java.util.Queue;

public class NearestZero {

    // TODO: 22/11/23  
    public int[][] updateMatrix(int[][] mat) {
        int[][] answer=new int[mat.length][mat[0].length];
        Queue<Integer> queue = new LinkedList<>();

        return null;
    }
}
