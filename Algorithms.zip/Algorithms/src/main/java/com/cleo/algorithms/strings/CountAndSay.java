package com.cleo.algorithms.strings;

public class CountAndSay {
    public String countAndSay(int n) {

        return new String();

    }
}
