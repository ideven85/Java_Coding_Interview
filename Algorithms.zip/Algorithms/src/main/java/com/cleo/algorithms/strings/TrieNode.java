package com.cleo.algorithms.strings;

class TrieNode {
    char c;
    TrieNode next;
    boolean isEnd;

    public TrieNode() {
    }
}
