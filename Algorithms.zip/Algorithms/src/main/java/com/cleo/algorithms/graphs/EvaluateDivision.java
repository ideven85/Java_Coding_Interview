package com.cleo.algorithms.graphs;

import java.util.*;
class SolutionEvaluateDivision {
    public double[] calcEquation(List<List<String>> equations, double[] values,
                                 List<List<String>> queries) {

        HashMap<String, HashMap<String, Double>> graph = new HashMap<>();

        // Step 1). build the graph from the equations
        for (int i = 0; i < equations.size(); i++) {
            List<String> equation = equations.get(i);
            String dividend = equation.get(0), divisor = equation.get(1);
            double quotient = values[i];

            if (!graph.containsKey(dividend))
                graph.put(dividend, new HashMap<String, Double>());
            if (!graph.containsKey(divisor))
                graph.put(divisor, new HashMap<String, Double>());

            graph.get(dividend).put(divisor, quotient);
            graph.get(divisor).put(dividend, 1 / quotient);
        }

        // Step 2). Evaluate each query via bactracking (DFS)
        // by verifying if there exists a path from dividend to divisor
        double[] results = new double[queries.size()];
        for (int i = 0; i < queries.size(); i++) {
            List<String> query = queries.get(i);
            String dividend = query.get(0), divisor = query.get(1);

            if (!graph.containsKey(dividend) || !graph.containsKey(divisor))
                results[i] = -1.0;
            else if (dividend == divisor)
                results[i] = 1.0;
            else {
                HashSet<String> visited = new HashSet<>();
                results[i] = backtrackEvaluate(graph, dividend, divisor, 1, visited);
            }
        }

        return results;
    }

    private double backtrackEvaluate(HashMap<String, HashMap<String, Double>> graph, String currNode, String targetNode, double accProduct, Set<String> visited) {

        // mark the visit
        visited.add(currNode);
        double ret = -1.0;

        Map<String, Double> neighbors = graph.get(currNode);
        if (neighbors.containsKey(targetNode))
            ret = accProduct * neighbors.get(targetNode);
        else {
            for (Map.Entry<String, Double> pair : neighbors.entrySet()) {
                String nextNode = pair.getKey();
                if (visited.contains(nextNode))
                    continue;
                ret = backtrackEvaluate(graph, nextNode, targetNode,
                        accProduct * pair.getValue(), visited);
                if (ret != -1.0)
                    break;
            }
        }

        // unmark the visit, for the next backtracking
        visited.remove(currNode);
        return ret;
    }
}

// TODO: 15/08/23  
public class EvaluateDivision {
    static class Pair{
        String node;
        double weight;

        public Pair(String node, double weight) {
            this.node = node;
            this.weight = weight;
        }
    }
    private final Map<String,List<Pair>> equationMap = new HashMap<>();
    private String[] root;

    private double dfsUtil(String source, String destination,Set<String> seen, double answer) {
        if(source.equals(destination))
            return answer;
        for(var pair:equationMap.get(source)){
            String connection= pair.node;
            double weight=pair.weight;
            if(seen.contains(connection))
                continue;
            seen.add(connection);
            answer*=weight;
            if(connection.equals(destination))
                return answer;
            dfsUtil(connection,destination,seen,answer);

        }
        return -1;

    }
    public double[] calcEquation(List<List<String>> equations, double[] values, List<List<String>> queries) {
        int i = 0;

        Set<String> set = new HashSet<>();
        for(var eq:equations) {
            set.add(eq.get(0));
            set.add(eq.get(1));
        }
        int size = set.size();
        for(var node:set)
            equationMap.put(node,new ArrayList<>());

        for (var eq : equations) {
            String source = eq.get(0);
            String destination = eq.get(1);
            double weight = values[i++];
            Pair p1 = new Pair(source, weight);
            Pair p2 = new Pair(destination, 1.0 / weight);

            equationMap.get(source).add(p1);
            equationMap.get(destination).add(p2);
        }
        i=0;
        double[] answer = new double[queries.size()];
        for (var query : queries) {
            String source = query.get(0);
            String destination = query.get(1);
            Set<String> seen = new HashSet<>();

            double value=dfsUtil(source,destination,seen,1);
            answer[i++]=value;


        }
        return answer;
    }

    public static void main(String[] args) {

    }

}

