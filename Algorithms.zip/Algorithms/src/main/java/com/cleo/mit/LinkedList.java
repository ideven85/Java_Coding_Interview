package com.cleo.mit;
/*

public class LinkedList<T> {

    private Object next_node;
    private LinkedList<T> element;
    private int index;
//    public LinkedList(int index,T element) {
//        if(index==0)
//            this.add(0,element);
//        this.element=element;
//
//    }
//    public LinkedList(){
//        this=this.next_node;
//    }


    public T get(int index) {
        for (int i = 0; i < index; i++) {
            this.next_node=this;
        }
        return this.element;

    }
    public void add(int index,T element) {
        for (int i = 0; i < index; i++) {
            this.next_node=this;
        }
        this.element=element;




    }

    public static void main(String[] args) {
        LinkedList<Integer> root = new LinkedList<>();
        root.add(0,2);
        root.add(1,3);
        System.out.println(root.get(0));
        System.out.println(root.get(1));
        System.out.println(root.get(2));
    }

}
*/
