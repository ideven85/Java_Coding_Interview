package Lecture23_Queues;

public class QueueEmptyException extends Exception{
}
