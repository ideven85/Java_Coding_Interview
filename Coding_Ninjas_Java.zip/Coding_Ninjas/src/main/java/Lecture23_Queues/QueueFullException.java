package Lecture23_Queues;

public class QueueFullException extends Exception{

}
