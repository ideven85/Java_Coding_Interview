package com.cleo;

public class Main {
    public static void main(String[] args) {
        Integer f=1;
        Integer s=1;
        if(f==s)
            System.out.println("Values are same");
        else
            System.out.println("Values are not same");
        float x= 100;
        byte b = 127;
        System.out.println(x);
        System.out.println((int)b+1);
        System.out.println("Hello world!");

    }
}