package com.cleo.fullTest2;

public class Node{
    int data;
    Node next;
    Node (int key)
    {
        data=key;
        next=null;
    }
}
