package LinekedList1;

public class LinkedListNode <T>{
    T data;
    LinkedListNode<T> next;

    public LinkedListNode(T data) {
        this.data = data;
    }
}
