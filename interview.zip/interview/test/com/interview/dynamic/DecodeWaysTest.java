package com.interview.dynamic;

import org.junit.Test;

public class DecodeWaysTest {
    @Test
    public void testDifferentCases() {
        DecodeWays decodeWays = new DecodeWays();
        System.out.println(decodeWays.numDecodings("20320"));
    }
}
