import fs from 'node:fs';

function getBalance(): number {
    // TODO: change fs.readFileSync() to fs.promises.readFile()
    //       then make the rest of the code work using promises
    const data: string = fs.readFileSync('savings', { encoding: 'utf-8' });
    return parseInt(data);
}

function main(): void {
    console.log('you have', getBalance(), 'dollars in your savings account');
}

main();
