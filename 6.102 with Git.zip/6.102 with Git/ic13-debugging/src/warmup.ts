
// Louis Reasoner likes all his variables up at the top
// where he can keep a close eye on them.
let sudoku: Sudoku;
let puzzle: Array<Array<number>>;

let row: number;
let column: number;
let block: number;

let firstRow: number;
let firstColumn: number;

let numbers: Set<number>;

let puzzleSize: number;
let blockSize: number;


function main(): void {
    puzzleSize = 4;
    sudoku = new Sudoku();
    do {
        sudoku.fillRandomly();
        sudoku.print();
    } while (!sudoku.isSolved());
    console.log("solved!");
}

class Sudoku {
    
    public constructor() {
        puzzle = [];
        for (row = 0; row < puzzleSize; ++row) {
            const row: Array<number> = [];
            for (column = 0; column < puzzleSize; ++column) {
                row.push(0);
            }
            puzzle.push(row);
        }
    }
    
    public fillRandomly(): void {
        for (row = 0; row < puzzle.length; ++row) {
            for (column = 0; column < puzzle.length; ++column) {
                // pick a random integer from 1 to puzzle.length inclusive
                puzzle[row][column] = 1 + Math.floor(Math.random() * puzzle.length);
            }
        }
    }
    
    public isSolved(): boolean {
        for (row = 0; row < puzzle.length; ++row) {
            numbers = new Set();
            for (column = 0; column < puzzle.length; ++column) {
                // === snapshot! draw a diagram of the 1st time we reach this point ===
                if (numbers.has(puzzle[row][column])) {
                    return false;
                }
                numbers.add(puzzle[row][column]);
            }
        }
        
        for (column = 0; column < puzzle.length; ++column) {
            numbers = new Set();
            for (row = 0; row < puzzle.length; ++row) {
                if (numbers.has(puzzle[row][column])) {
                    return false;
                }
                numbers.add(puzzle[row][column]);
            }
        }
                
        for (block = 0; block < puzzle.length; ++block) {
            numbers = new Set();
            blockSize = Math.floor(Math.sqrt(puzzle.length));
            firstRow = block / blockSize;
            firstColumn = block % blockSize;
            for (row = 0; row < blockSize; ++row) {
                for (column = 0; column < blockSize; ++column) {
                    if (numbers.has(puzzle[firstRow+row][firstColumn+column])) {
                        return false;
                    }
                    numbers.add(puzzle[firstRow+row][firstColumn+column]);
                }
            }
        }
        
        return true;
    }

    public print(): void {
        let printout = "";
        for (row = 0; row < puzzle.length; ++row) {
            for (column = 0; column < puzzle.length; ++column) {
                printout += puzzle[row][column];
            }
            printout += "\n";
        }
        console.log(printout);
    }
}


main();
