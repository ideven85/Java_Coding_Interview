import { main } from './factorial.js';
main();
