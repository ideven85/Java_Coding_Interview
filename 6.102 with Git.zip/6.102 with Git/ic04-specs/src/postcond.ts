
export function evaluateParabola(a: Array<number>, x: number): number
// requires: true
// effects: ???
{ throw new Error("not implementing today"); }



export function factor(n: bigint): { p: bigint, q: bigint }
// requires: n > 0
// effects: ???
{ throw new Error("not implementing today"); }



export function deleteAllOccurrences(a: Array<number>, value: number): void
// requires: true
// effects: ???
{ throw new Error("not implementing today"); }



export function split(s: string, separator: string): Array<string>
// requires: separator.length = 1
// effects: ???
{ throw new Error("not implementing today"); }
