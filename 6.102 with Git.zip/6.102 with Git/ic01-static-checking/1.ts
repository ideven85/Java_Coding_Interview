let s="abc";
s.concat("123");
console.log(s);
