data = [ 2, 4, 6 ]
total = 0
average = 0
n = 0
for value in data:
    n += 1
    total += value
    average = total / n
    print(average)
